import React from 'react';

const Adnan = () => {
    return (
        <div>
            madarchod 
        </div>
    );
};

export default Adnan;